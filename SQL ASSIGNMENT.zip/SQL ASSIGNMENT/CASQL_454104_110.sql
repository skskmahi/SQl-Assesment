USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_110') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_110
GO

--EXEC CASQL_454104_110
Create Proc CASQL_454104_110
AS
BEGIN
SELECT FORMAT(eph.modifiedDate,'yyyy/MM/dd','en-US' ) AS ISOFormattedDate,
	   FORMAT(eph.rate,'C', 'en-US') AS USCurrency,
	   FORMAT(eph.rate,'C', 'en-US') AS UKCurrency
FROM HumanResources.EmployeePayHistory AS eph

END
GO