USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_106') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_106
GO

--EXEC CASQL_454104_106
Create Proc CASQL_454104_106
AS
BEGIN
IF (OBJECT_ID('UnpivotTable') IS NOT NULL)
  DROP TABLE [dbo].[UnpivotTable]

SELECT *
INTO   [dbo].[UnpivotTable]
FROM (
    SELECT 
        year(ModifiedDate) as [ModifiedYear],
        Rate, 
        EmployeeID 
    FROM HumanResources.EmployeePayHistory
    WHERE EmployeeID = 4
) as s
PIVOT
(
    SUM(Rate)
    FOR [ModifiedYear] IN ([1997],[2000],[2002])
)AS pvt

SELECT * FROM [dbo].[UnpivotTable] ORDER BY EmployeeID

SELECT   EmployeeID, [ModifiedYear], Rate 
FROM [dbo].[UnpivotTable]
UNPIVOT
(
       Rate
       FOR [ModifiedYear] IN ([1997], [2000], [2002])
) AS P

END
GO