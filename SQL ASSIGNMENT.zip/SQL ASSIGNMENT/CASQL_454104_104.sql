USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_104') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_104
GO

--EXEC CASQL_454104_104
Create Proc CASQL_454104_104
AS
BEGIN
SELECT  c.FirstName + ' ' + c.LastName AS Name, 
		d.Name AS Department,
		CASE WHEN c1.FirstName IS NULL AND c1.LastName IS NULL THEN 'CEO'
		ELSE c1.FirstName + ' ' + c1.LastName END AS Manager,		
		a.City, 
		s.StateProvinceCode,
		cr.CountryRegionCode
FROM HumanResources.Employee AS e
LEFT JOIN HumanResources.Employee AS e1
	ON e.ManagerID = e1.EmployeeID
LEFT JOIN Person.Contact AS c1
	ON e1.ContactID = c1.ContactID
INNER JOIN HumanResources.EmployeeDepartmentHistory AS edh
	ON e.EmployeeID = edh.EmployeeID
INNER JOIN HumanResources.Department AS d
	ON d.DepartmentID = edh.DepartmentID
INNER JOIN Person.Contact AS c
	ON e.ContactID = c.ContactID
INNER JOIN HumanResources.EmployeeAddress AS ea
	ON e.EmployeeID = ea.EmployeeID
INNER JOIN Person.[Address] AS a
	ON ea.AddressID = a.AddressID
INNER JOIN Person.StateProvince AS s
	ON a.StateProvinceID = s.StateProvinceID
INNER JOIN Person.CountryRegion AS cr
	ON s.CountryRegionCode = cr.CountryRegionCode
WHERE a.City LIKE '%Renton%'
ORDER BY d.Name DESC
END
GO