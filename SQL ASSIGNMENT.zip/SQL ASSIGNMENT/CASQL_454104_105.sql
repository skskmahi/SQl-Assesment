USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_105') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_105
GO

--EXEC CASQL_454104_105
Create Proc CASQL_454104_105
AS
BEGIN
MERGE INTO Person.StateProvince AS p
USING Person.CountryRegion AS cr
        ON p.CountryRegionCode = cr.CountryRegionCode
WHEN MATCHED AND cr.CountryRegionCode = 'ZZ' 
    THEN DELETE
WHEN MATCHED AND cr.CountryRegionCode = 'ZY'  
	THEN 	
      UPDATE SET p.ModifiedDate = DATEADD(day, -2, p.ModifiedDate);
END
GO