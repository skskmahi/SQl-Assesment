USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_108') IS NOT NULL)
  DROP FUNCTION CASQL_454104_108
GO

--Select * from  CASQL_454104_108(4)
Create FUNCTION CASQL_454104_108
(@EmployeeID INT)
RETURNS @EmployeeData TABLE
(
	EmployeeName VARCHAR(100),
	Gender nchar(1),
	EmployeeID INT NOT NULL,
	ManagerID INT NOT NULL,
	Title NVARCHAR(50)
)
AS
BEGIN
DECLARE 
	@EmployeeName VARCHAR(100),
	@Gender nchar(1),
	@EmployeeIdentification INT,
	@ManagerID INT,
	@Title NVARCHAR(50)
	
SELECT @EmployeeName = c.FirstName + ' ' + c.LastName, 
		@Gender = e.Gender,
		@EmployeeIdentification = e.EmployeeID, 
		@ManagerID = e.ManagerID,
		@Title = e.Title
FROM HumanResources.Employee AS e
INNER JOIN Person.Contact AS c
	ON e.ContactID = c.ContactID
WHERE e.EmployeeID = EmployeeID

INSERT INTO @EmployeeData (EmployeeName, Gender, EmployeeID, ManagerID, Title)
VALUES (@EmployeeName, @Gender, @EmployeeID, @ManagerID, @Title)

RETURN;
END
GO