USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF OBJECT_ID('HumanResources.vEmployeeDepartment', 'V') IS NOT NULL
    DROP VIEW HumanResources.vEmployeeDepartment
GO

CREATE VIEW HumanResources.vEmployeeDepartment
AS
	SELECT c.LastName, c.FirstName, e.EmployeeID, d.Name AS Department, d.GroupName
	FROM HumanResources.Employee AS e
	INNER JOIN Person.Contact AS c
		ON e.ContactID = c.ContactID
	INNER JOIN HumanResources.EmployeeDepartmentHistory AS edh
		ON e.EmployeeID = edh.EmployeeID
	INNER JOIN HumanResources.Department AS d
		ON d.DepartmentID = edh.DepartmentID
GO

IF (OBJECT_ID('CASQL_454104_109') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_109
GO

--EXEC CASQL_454104_109
Create Proc CASQL_454104_109
AS
BEGIN
SELECT ed.FirstName, ed.LastName, ed.Department, ed.GroupName, e.Gender, YEAR(e.HireDate) AS Year
FROM HumanResources.Employee AS e
INNER JOIN HumanResources.vEmployeeDepartment AS ed
	ON e.EmployeeID = ed.EmployeeID
ORDER BY ed.Department	

END
GO