USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_103') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_103
GO

--EXEC CASQL_454104_103
Create Proc CASQL_454104_103
AS
BEGIN
SELECT c.LastName, c.FirstName, a.City, s.StateProvinceCode
FROM HumanResources.Employee AS e
INNER JOIN Person.Contact AS c
	ON e.ContactID = c.ContactID
INNER JOIN HumanResources.EmployeeAddress AS ea
	ON e.EmployeeID = ea.EmployeeID
INNER JOIN Person.[Address] AS a
	ON ea.AddressID = a.AddressID
INNER JOIN Person.StateProvince AS s
	ON a.StateProvinceID = s.StateProvinceID
WHERE s.StateProvinceCode = 'WA'
END
GO