
select * from HumanResources.Department
select * from HumanResources.Employee
select * from HumanResources.EmployeeDepartmentHistory
select * from HumanResources.Shift

select * from HumanResources.EmployeePayHistory

select * from Person.Contact
select * from Person.ContactType

select * from HumanResources.EmployeeAddress
select * from Person.Address
select * from Person.AddressType
select * from Person.CountryRegion
select * from Person.StateProvince



