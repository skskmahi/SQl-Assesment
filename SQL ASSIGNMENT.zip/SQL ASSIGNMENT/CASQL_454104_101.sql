USE [CASQL]
GO

SET ANSI_NULLS OFF
GO

IF (OBJECT_ID('CASQL_454104_101') IS NOT NULL)
  DROP PROCEDURE CASQL_454104_101
GO

--EXEC CASQL_454104_101
Create Proc CASQL_454104_101
AS
BEGIN
SELECT c.LastName, c.FirstName, e.EmployeeID, d.Name AS Department,eph.Rate
FROM HumanResources.Employee AS e
INNER JOIN Person.Contact AS c
	ON e.ContactID = c.ContactID
INNER JOIN HumanResources.EmployeeDepartmentHistory AS edh
	ON e.EmployeeID = edh.EmployeeID
INNER JOIN HumanResources.Department AS d
	ON d.DepartmentID = edh.DepartmentID
INNER JOIN HumanResources.EmployeePayHistory AS eph
	ON e.EmployeeID = eph.EmployeeID
END
GO